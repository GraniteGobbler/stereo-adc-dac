module.exports = {
	"Adafruit Boards":[0x239A,0xFFFF],
	"TinyUSB example":[0xCAFE,0xFFFF]
}
